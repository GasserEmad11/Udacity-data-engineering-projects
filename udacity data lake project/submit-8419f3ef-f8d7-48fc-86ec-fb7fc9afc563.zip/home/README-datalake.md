# Project Title

Data lake project

## Description

This project focuses on dealing with the sparkify database using tools like spark,hadoop to perform ELT processes for better functionality and performance 

## Getting Started
The project folder contains two files :
dl.cfg : file containing the aws credentials
etl.py: python script that performs the ETL process
### Dependencies
A couple of libaries are needed for this project to be installed :
1-pyspark: handles all the instances of spark needed for the script .
2-configparser: needed to read the configurations in the dwh.cfg file.
3-os: used to set the enviroment variables 


### Executing program
The project needs to be executed in a ceratin order which is :
1- write the aws credentials in the dl.cfg file 
2-running the etl.py script 






